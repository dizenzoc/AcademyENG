package it.eng.corso.dip.scenario1;

public class Service {

    public void saluta(){
        System.out.println("ciao sono Service di scenario 1");
    }
}

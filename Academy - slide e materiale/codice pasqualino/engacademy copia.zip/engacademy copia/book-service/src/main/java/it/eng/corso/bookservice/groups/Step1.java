package it.eng.corso.bookservice.groups;

public interface Step1 {
}
